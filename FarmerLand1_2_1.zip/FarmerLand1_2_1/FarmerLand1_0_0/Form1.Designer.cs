﻿namespace FarmerLand
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Pl = new System.Windows.Forms.Label();
            this.Y1 = new System.Windows.Forms.Label();
            this.Wa = new System.Windows.Forms.Label();
            this.X1 = new System.Windows.Forms.Label();
            this.Ga = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.Gr = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Ir = new System.Windows.Forms.Label();
            this.Tr = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.plantToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cornToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wheatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.carrotsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.harvestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tractorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.irrigationSystemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.greenhouseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sellToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tractorToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.watererToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.planterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expandFieldToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CashOut = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.RotTimer = new System.Windows.Forms.Timer(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.BCows = new System.Windows.Forms.Button();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.Sheep = new System.Windows.Forms.Label();
            this.Cow = new System.Windows.Forms.Label();
            this.Pig = new System.Windows.Forms.Label();
            this.BPigs = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.BSheep = new System.Windows.Forms.Button();
            this.AnimalTimer = new System.Windows.Forms.Timer(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Pl);
            this.groupBox1.Controls.Add(this.Y1);
            this.groupBox1.Controls.Add(this.Wa);
            this.groupBox1.Controls.Add(this.X1);
            this.groupBox1.Controls.Add(this.Ga);
            this.groupBox1.Controls.Add(this.progressBar1);
            this.groupBox1.Controls.Add(this.Gr);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.Ir);
            this.groupBox1.Controls.Add(this.Tr);
            this.groupBox1.Controls.Add(this.menuStrip1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(283, 391);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Crops";
            // 
            // Pl
            // 
            this.Pl.AutoSize = true;
            this.Pl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Pl.Location = new System.Drawing.Point(38, 366);
            this.Pl.Name = "Pl";
            this.Pl.Size = new System.Drawing.Size(24, 20);
            this.Pl.TabIndex = 10;
            this.Pl.Text = "Pl";
            // 
            // Y1
            // 
            this.Y1.AutoSize = true;
            this.Y1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Y1.Location = new System.Drawing.Point(6, 284);
            this.Y1.Name = "Y1";
            this.Y1.Size = new System.Drawing.Size(75, 25);
            this.Y1.TabIndex = 4;
            this.Y1.Text = "Size Y:";
            // 
            // Wa
            // 
            this.Wa.AutoSize = true;
            this.Wa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Wa.Location = new System.Drawing.Point(38, 346);
            this.Wa.Name = "Wa";
            this.Wa.Size = new System.Drawing.Size(34, 20);
            this.Wa.TabIndex = 9;
            this.Wa.Text = "Wa";
            // 
            // X1
            // 
            this.X1.AutoSize = true;
            this.X1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.X1.Location = new System.Drawing.Point(6, 259);
            this.X1.Name = "X1";
            this.X1.Size = new System.Drawing.Size(76, 25);
            this.X1.TabIndex = 3;
            this.X1.Text = "Size X:";
            // 
            // Ga
            // 
            this.Ga.AutoSize = true;
            this.Ga.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Ga.Location = new System.Drawing.Point(38, 326);
            this.Ga.Name = "Ga";
            this.Ga.Size = new System.Drawing.Size(31, 20);
            this.Ga.TabIndex = 8;
            this.Ga.Text = "Ga";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(2, 224);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(277, 23);
            this.progressBar1.TabIndex = 1;
            this.progressBar1.Click += new System.EventHandler(this.progressBar1_Click);
            // 
            // Gr
            // 
            this.Gr.AutoSize = true;
            this.Gr.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Gr.Location = new System.Drawing.Point(7, 366);
            this.Gr.Name = "Gr";
            this.Gr.Size = new System.Drawing.Size(28, 20);
            this.Gr.TabIndex = 7;
            this.Gr.Text = "Gr";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(3, 63);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(276, 155);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Ir
            // 
            this.Ir.AutoSize = true;
            this.Ir.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Ir.Location = new System.Drawing.Point(7, 346);
            this.Ir.Name = "Ir";
            this.Ir.Size = new System.Drawing.Size(19, 20);
            this.Ir.TabIndex = 6;
            this.Ir.Text = "Ir";
            // 
            // Tr
            // 
            this.Tr.AutoSize = true;
            this.Tr.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Tr.Location = new System.Drawing.Point(7, 326);
            this.Tr.Name = "Tr";
            this.Tr.Size = new System.Drawing.Size(25, 20);
            this.Tr.TabIndex = 5;
            this.Tr.Text = "Tr";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.plantToolStripMenuItem,
            this.harvestToolStripMenuItem,
            this.otherToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(3, 32);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(277, 28);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // plantToolStripMenuItem
            // 
            this.plantToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cornToolStripMenuItem,
            this.wheatToolStripMenuItem,
            this.carrotsToolStripMenuItem});
            this.plantToolStripMenuItem.Name = "plantToolStripMenuItem";
            this.plantToolStripMenuItem.Size = new System.Drawing.Size(54, 24);
            this.plantToolStripMenuItem.Text = "Plant";
            this.plantToolStripMenuItem.Click += new System.EventHandler(this.plantToolStripMenuItem_Click);
            // 
            // cornToolStripMenuItem
            // 
            this.cornToolStripMenuItem.Name = "cornToolStripMenuItem";
            this.cornToolStripMenuItem.Size = new System.Drawing.Size(131, 26);
            this.cornToolStripMenuItem.Text = "Corn";
            this.cornToolStripMenuItem.Click += new System.EventHandler(this.cornToolStripMenuItem_Click);
            // 
            // wheatToolStripMenuItem
            // 
            this.wheatToolStripMenuItem.Name = "wheatToolStripMenuItem";
            this.wheatToolStripMenuItem.Size = new System.Drawing.Size(131, 26);
            this.wheatToolStripMenuItem.Text = "Wheat";
            this.wheatToolStripMenuItem.Click += new System.EventHandler(this.wheatToolStripMenuItem_Click);
            // 
            // carrotsToolStripMenuItem
            // 
            this.carrotsToolStripMenuItem.Name = "carrotsToolStripMenuItem";
            this.carrotsToolStripMenuItem.Size = new System.Drawing.Size(131, 26);
            this.carrotsToolStripMenuItem.Text = "Carrots";
            this.carrotsToolStripMenuItem.Click += new System.EventHandler(this.carrotsToolStripMenuItem_Click);
            // 
            // harvestToolStripMenuItem
            // 
            this.harvestToolStripMenuItem.Name = "harvestToolStripMenuItem";
            this.harvestToolStripMenuItem.Size = new System.Drawing.Size(71, 24);
            this.harvestToolStripMenuItem.Text = "Harvest";
            this.harvestToolStripMenuItem.Click += new System.EventHandler(this.harvestToolStripMenuItem_Click);
            // 
            // otherToolStripMenuItem
            // 
            this.otherToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buyToolStripMenuItem,
            this.sellToolStripMenuItem,
            this.expandFieldToolStripMenuItem});
            this.otherToolStripMenuItem.Name = "otherToolStripMenuItem";
            this.otherToolStripMenuItem.Size = new System.Drawing.Size(58, 24);
            this.otherToolStripMenuItem.Text = "Other";
            // 
            // buyToolStripMenuItem
            // 
            this.buyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tractorToolStripMenuItem,
            this.irrigationSystemToolStripMenuItem,
            this.greenhouseToolStripMenuItem});
            this.buyToolStripMenuItem.Name = "buyToolStripMenuItem";
            this.buyToolStripMenuItem.Size = new System.Drawing.Size(169, 26);
            this.buyToolStripMenuItem.Text = "Buy";
            // 
            // tractorToolStripMenuItem
            // 
            this.tractorToolStripMenuItem.Name = "tractorToolStripMenuItem";
            this.tractorToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.tractorToolStripMenuItem.Text = "Tractor (10000)";
            this.tractorToolStripMenuItem.Click += new System.EventHandler(this.tractorToolStripMenuItem_Click);
            // 
            // irrigationSystemToolStripMenuItem
            // 
            this.irrigationSystemToolStripMenuItem.Name = "irrigationSystemToolStripMenuItem";
            this.irrigationSystemToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.irrigationSystemToolStripMenuItem.Text = "Irrigation System (5000)";
            this.irrigationSystemToolStripMenuItem.Click += new System.EventHandler(this.irrigationSystemToolStripMenuItem_Click);
            // 
            // greenhouseToolStripMenuItem
            // 
            this.greenhouseToolStripMenuItem.Name = "greenhouseToolStripMenuItem";
            this.greenhouseToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.greenhouseToolStripMenuItem.Text = "Greenhouse (100000)";
            this.greenhouseToolStripMenuItem.Click += new System.EventHandler(this.greenhouseToolStripMenuItem_Click);
            // 
            // sellToolStripMenuItem
            // 
            this.sellToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tractorToolStripMenuItem1,
            this.watererToolStripMenuItem,
            this.planterToolStripMenuItem});
            this.sellToolStripMenuItem.Name = "sellToolStripMenuItem";
            this.sellToolStripMenuItem.Size = new System.Drawing.Size(169, 26);
            this.sellToolStripMenuItem.Text = "Hire";
            // 
            // tractorToolStripMenuItem1
            // 
            this.tractorToolStripMenuItem1.Name = "tractorToolStripMenuItem1";
            this.tractorToolStripMenuItem1.Size = new System.Drawing.Size(191, 26);
            this.tractorToolStripMenuItem1.Text = "Gardener (2000)";
            this.tractorToolStripMenuItem1.Click += new System.EventHandler(this.tractorToolStripMenuItem1_Click);
            // 
            // watererToolStripMenuItem
            // 
            this.watererToolStripMenuItem.Name = "watererToolStripMenuItem";
            this.watererToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.watererToolStripMenuItem.Text = "Waterer(3000)";
            this.watererToolStripMenuItem.Click += new System.EventHandler(this.watererToolStripMenuItem_Click);
            // 
            // planterToolStripMenuItem
            // 
            this.planterToolStripMenuItem.Name = "planterToolStripMenuItem";
            this.planterToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.planterToolStripMenuItem.Text = "Planter(15000)";
            this.planterToolStripMenuItem.Click += new System.EventHandler(this.planterToolStripMenuItem_Click);
            // 
            // expandFieldToolStripMenuItem
            // 
            this.expandFieldToolStripMenuItem.Name = "expandFieldToolStripMenuItem";
            this.expandFieldToolStripMenuItem.Size = new System.Drawing.Size(169, 26);
            this.expandFieldToolStripMenuItem.Text = "Expand Field";
            this.expandFieldToolStripMenuItem.Click += new System.EventHandler(this.expandFieldToolStripMenuItem_ClickAsync);
            // 
            // CashOut
            // 
            this.CashOut.AutoSize = true;
            this.CashOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.CashOut.Location = new System.Drawing.Point(12, 413);
            this.CashOut.Name = "CashOut";
            this.CashOut.Size = new System.Drawing.Size(0, 25);
            this.CashOut.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.button1.Location = new System.Drawing.Point(697, 413);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(175, 27);
            this.button1.TabIndex = 2;
            this.button1.Text = "Declare Bankruptcy";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            // 
            // RotTimer
            // 
            this.RotTimer.Interval = 500;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.BCows);
            this.groupBox2.Controls.Add(this.progressBar2);
            this.groupBox2.Controls.Add(this.Sheep);
            this.groupBox2.Controls.Add(this.Cow);
            this.groupBox2.Controls.Add(this.Pig);
            this.groupBox2.Controls.Add(this.BPigs);
            this.groupBox2.Controls.Add(this.pictureBox2);
            this.groupBox2.Controls.Add(this.BSheep);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.groupBox2.Location = new System.Drawing.Point(301, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(283, 391);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Animals";
            // 
            // BCows
            // 
            this.BCows.Location = new System.Drawing.Point(0, 300);
            this.BCows.Name = "BCows";
            this.BCows.Size = new System.Drawing.Size(283, 46);
            this.BCows.TabIndex = 0;
            this.BCows.Text = "Purchase Cows";
            this.BCows.UseVisualStyleBackColor = true;
            this.BCows.Click += new System.EventHandler(this.BCows_Click);
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(0, 224);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(283, 23);
            this.progressBar2.TabIndex = 11;
            // 
            // Sheep
            // 
            this.Sheep.AutoSize = true;
            this.Sheep.Location = new System.Drawing.Point(100, 31);
            this.Sheep.Name = "Sheep";
            this.Sheep.Size = new System.Drawing.Size(86, 29);
            this.Sheep.TabIndex = 15;
            this.Sheep.Text = "Sheep";
            // 
            // Cow
            // 
            this.Cow.AutoSize = true;
            this.Cow.Location = new System.Drawing.Point(6, 31);
            this.Cow.Name = "Cow";
            this.Cow.Size = new System.Drawing.Size(63, 29);
            this.Cow.TabIndex = 14;
            this.Cow.Text = "Cow";
            // 
            // Pig
            // 
            this.Pig.AutoSize = true;
            this.Pig.Location = new System.Drawing.Point(227, 32);
            this.Pig.Name = "Pig";
            this.Pig.Size = new System.Drawing.Size(50, 29);
            this.Pig.TabIndex = 13;
            this.Pig.Text = "Pig";
            // 
            // BPigs
            // 
            this.BPigs.Location = new System.Drawing.Point(0, 300);
            this.BPigs.Name = "BPigs";
            this.BPigs.Size = new System.Drawing.Size(283, 46);
            this.BPigs.TabIndex = 12;
            this.BPigs.Text = "Purchase Pigs";
            this.BPigs.UseVisualStyleBackColor = true;
            this.BPigs.Click += new System.EventHandler(this.BPigs_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(0, 63);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(283, 155);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // BSheep
            // 
            this.BSheep.Location = new System.Drawing.Point(0, 300);
            this.BSheep.Name = "BSheep";
            this.BSheep.Size = new System.Drawing.Size(283, 46);
            this.BSheep.TabIndex = 1;
            this.BSheep.Text = "Purchase Sheep";
            this.BSheep.UseVisualStyleBackColor = true;
            this.BSheep.Click += new System.EventHandler(this.BSheep_Click);
            // 
            // AnimalTimer
            // 
            this.AnimalTimer.Interval = 10000;
            this.AnimalTimer.Tick += new System.EventHandler(this.AnimalTimer_Tick);
            // 
            // groupBox3
            // 
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.groupBox3.Location = new System.Drawing.Point(590, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(283, 391);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Buildings";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(884, 448);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.CashOut);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Farmer Land";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem plantToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem harvestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem otherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tractorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem irrigationSystemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem greenhouseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sellToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tractorToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem watererToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem planterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cornToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wheatToolStripMenuItem;
        private System.Windows.Forms.Label CashOut;
        private System.Windows.Forms.ToolStripMenuItem expandFieldToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Y1;
        private System.Windows.Forms.Label X1;
        private System.Windows.Forms.ToolStripMenuItem carrotsToolStripMenuItem;
        private System.Windows.Forms.Label Pl;
        private System.Windows.Forms.Label Wa;
        private System.Windows.Forms.Label Ga;
        private System.Windows.Forms.Label Gr;
        private System.Windows.Forms.Label Ir;
        private System.Windows.Forms.Label Tr;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer RotTimer;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button BCows;
        private System.Windows.Forms.Button BPigs;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button BSheep;
        private System.Windows.Forms.Label Sheep;
        private System.Windows.Forms.Label Cow;
        private System.Windows.Forms.Label Pig;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.Timer AnimalTimer;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}

